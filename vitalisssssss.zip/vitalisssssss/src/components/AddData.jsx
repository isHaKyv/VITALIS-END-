import React, { useState, useEffect } from 'react';
import { Line } from 'react-chartjs-2';
import { useNavigate } from 'react-router-dom';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import '../styles/AddData.css';

const AddData = ({ setPatientFiles, patientFiles }) => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        fullName: '',
        dob: '',
        age: '',
        gender: '',
        maritalStatus: '',
        address: '',
        generalSensorData: '',
        recentSensorData: '',
    });

    const [sensorData, setSensorData] = useState([]);
    const [chartData, setChartData] = useState([]);

    // Establish WebSocket connection
    useEffect(() => {
        const ws = new WebSocket('ws://localhost:8080'); // Replace with your WebSocket URL

        ws.onmessage = (event) => {
            const sensorValue = JSON.parse(event.data);
            setSensorData((prev) => [...prev, sensorValue]);
            setChartData((prev) => [...prev, sensorValue.value]);
            setFormData((prev) => ({
                ...prev,
                recentSensorData: sensorValue.value,
            }));
        };

        return () => ws.close();
    }, []);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleDOBChange = (e) => {
        const dob = e.target.value;
        const age = new Date().getFullYear() - new Date(dob).getFullYear();
        setFormData((prev) => ({ ...prev, dob, age }));
    };

    const handleSave = () => {
        if (formData.fullName && formData.dob && formData.gender && formData.address) {
            const patientData = {
                ...formData,
                sensorData,
                timestamp: new Date(),
            };

            setPatientFiles([...patientFiles, { ...patientData, id: Date.now() }]);
            setFormData({
                fullName: '',
                dob: '',
                age: '',
                gender: '',
                maritalStatus: '',
                address: '',
                generalSensorData: '',
                recentSensorData: '',
            });
            setSensorData([]);
            navigate('/records');
        } else {
            alert('Please fill in the required fields.');
        }
    };

    const generatePDF = async () => {
        const pdf = new jsPDF();
    
        pdf.setFontSize(16);
        pdf.text("Patient Report", 105, 20, null, null, "center"); // Centered title
    
        pdf.setFontSize(12);
    
        // Patient Details Section
        pdf.text("Name:", 20, 40);
        pdf.text(formData.fullName || "N/A", 60, 40);
    
        pdf.text("Age:", 20, 50);
        pdf.text(formData.age || "N/A", 60, 50);
    
        pdf.text("Gender:", 20, 60);
        pdf.text(formData.gender || "N/A", 60, 60);
    
        pdf.text("Marital Status:", 20, 70);
        pdf.text(formData.maritalStatus || "N/A", 60, 70);
    
        pdf.text("Address:", 20, 80);
        pdf.text(formData.address || "N/A", 60, 80);
    
        // Sensor Data Section
        pdf.text("General Sensor Data:", 20, 100);
        pdf.text(formData.generalSensorData || "N/A", 60, 100);
    
        pdf.text("Most Recent Sensor Data:", 20, 110);
        pdf.text(formData.recentSensorData || "N/A", 60, 110);
    
        // Add chart as an image
        const chartElement = document.querySelector(".chart canvas");
        if (chartElement) {
            const chartCanvas = await html2canvas(chartElement);
            const chartImage = chartCanvas.toDataURL("image/png");
            pdf.addImage(chartImage, "PNG", 20, 120, 170, 80); // Position and size
        }
    
        pdf.save(`${formData.fullName || "Patient"}_Report.pdf`);
    };
    

    const lineChartData = {
        labels: sensorData.map((_, index) => `T${index + 1}`),
        datasets: [
            {
                label: 'Sensor Data',
                data: chartData,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                fill: true,
            },
        ],
    };

    return (
        <div className="add-data-container">
            <h2>Add Patient Data</h2>
            <form className="add-data-form" onSubmit={(e) => e.preventDefault()}>
                <div className="form-group">
                    <label>Full Name</label>
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Date of Birth</label>
                    <input
                        type="date"
                        name="dob"
                        value={formData.dob}
                        onChange={handleDOBChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="number" value={formData.age} readOnly />
                </div>
                <div className="form-group">
                    <label>Gender</label>
                    <select
                        name="gender"
                        value={formData.gender}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                <div className="form-group">
                    <label>Marital Status</label>
                    <input
                        type="text"
                        name="maritalStatus"
                        value={formData.maritalStatus}
                        onChange={handleChange}
                    />
                </div>
                <div className="form-group">
                    <label>Address</label>
                    <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                    ></textarea>
                </div>
                <div className="form-group">
                    <label>General Sensor Data</label>
                    <textarea
                        name="generalSensorData"
                        value={formData.generalSensorData}
                        onChange={handleChange}
                    ></textarea>
                </div>
                <div className="form-group">
                    <label>Most Recent Sensor Data</label>
                    <input
                        type="text"
                        name="recentSensorData"
                        value={formData.recentSensorData}
                        readOnly
                    />
                </div>
            </form>

            <div id="report" className="sensor-data-section">
                <h3>Sensor Data</h3>
                <div className="chart">
                    <Line data={lineChartData} />
                </div>
                <ul>
                    {sensorData.map((data, index) => (
                        <li key={index}>Value: {data.value}</li>
                    ))}
                </ul>
            </div>

            <div className="action-buttons">
                <button onClick={handleSave}>Save</button>
                <button onClick={generatePDF}>Generate PDF</button>
            </div>
        </div>
    );
};

export default AddData;
