import React from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Line, Bar, Pie } from 'react-chartjs-2';
import '../styles/Statistics.css';

// Register required components with Chart.js
ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend
);

const Statistics = () => {
    // Placeholder data for demonstration
    const sensorData = [
        { timestamp: '2024-11-01', value: 20 },
        { timestamp: '2024-11-02', value: 22 },
        { timestamp: '2024-11-03', value: 21 },
        { timestamp: '2024-11-04', value: 23 },
        { timestamp: '2024-11-05', value: 24 },
    ];

    const mean = sensorData.reduce((sum, data) => sum + data.value, 0) / sensorData.length;

    // Forecast (basic incremental prediction)
    const forecast = sensorData.map((_, index) => mean + index * 0.5);

    const lineData = {
        labels: sensorData.map((data) => data.timestamp),
        datasets: [
            {
                label: 'Sensor Readings',
                data: sensorData.map((data) => data.value),
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                fill: true,
            },
            {
                label: 'Forecast',
                data: forecast,
                borderColor: 'rgba(255, 99, 132, 1)',
                borderDash: [5, 5],
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                fill: false,
            },
        ],
    };

    const barData = {
        labels: sensorData.map((data) => data.timestamp),
        datasets: [
            {
                label: 'Sensor Readings',
                data: sensorData.map((data) => data.value),
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
            },
        ],
    };

    const pieData = {
        labels: ['Low', 'Medium', 'High'],
        datasets: [
            {
                data: [
                    sensorData.filter((data) => data.value < 22).length,
                    sensorData.filter((data) => data.value >= 22 && data.value <= 23).length,
                    sensorData.filter((data) => data.value > 23).length,
                ],
                backgroundColor: ['rgba(75, 192, 192, 0.6)', 'rgba(255, 206, 86, 0.6)', 'rgba(255, 99, 132, 0.6)'],
            },
        ],
    };

    return (
        <div className="statistics-container">
            <h2>Sensor Statistics</h2>

            {/* Charts */}
            <div className="charts">
                <div className="chart">
                    <Line data={lineData} />
                </div>
                <div className="chart">
                    <Bar data={barData} />
                </div>
                <div className="chart">
                    <Pie data={pieData} />
                </div>
            </div>
        </div>
    );
};

export default Statistics;
