import React, { useState } from 'react';
import '../styles/AddFile.css';


const AddFile = ({ patientFiles, setPatientFiles }) => {
    const [formData, setFormData] = useState({
        fullName: '',
        dob: '',
        age: '',
        sex: '',
        maritalStatus: '',
        address: '',
        generalSensorData: '',
        recentSensorData: '',
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
    };

    const handleSave = () => {
        if (formData.fullName && formData.dob && formData.sex && formData.maritalStatus && formData.address) {
            const age = new Date().getFullYear() - new Date(formData.dob).getFullYear();
            setPatientFiles([
                ...patientFiles,
                { ...formData, id: Date.now(), age: age },
            ]);
            setFormData({
                fullName: '',
                dob: '',
                age: '',
                sex: '',
                maritalStatus: '',
                address: '',
                generalSensorData: '',
                recentSensorData: '',
            });
        } else {
            alert('Please fill in all required fields.');
        }
    };

    return (
        <div className="add-file-container">
            <h2>Add Patient File</h2>
            <form className="add-file-form" onSubmit={(e) => e.preventDefault()}>
                <div className="form-group">
                    <label>Full Name</label>
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Date of Birth</label>
                    <input
                        type="date"
                        name="dob"
                        value={formData.dob}
                        onChange={(e) => {
                            const dob = e.target.value;
                            const age = new Date().getFullYear() - new Date(dob).getFullYear();
                            setFormData((prev) => ({ ...prev, dob, age }));
                        }}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Age</label>
                    <input type="number" value={formData.age} readOnly />
                </div>
                <div className="form-group">
                    <label>Sex</label>
                    <select
                        name="sex"
                        value={formData.sex}
                        onChange={handleChange}
                        required
                    >
                        <option value="">Select</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
                <div className="form-group">
                    <label>Marital Status</label>
                    <input
                        type="text"
                        name="maritalStatus"
                        value={formData.maritalStatus}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="form-group">
                    <label>Address</label>
                    <textarea
                        name="address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                    ></textarea>
                </div>
                <div className="form-group">
                    <label>General Sensor Data</label>
                    <textarea
                        name="generalSensorData"
                        value={formData.generalSensorData}
                        onChange={handleChange}
                    ></textarea>
                </div>
                <div className="form-group">
                    <label>Most Recent Sensor Data</label>
                    <input
                        type="text"
                        name="recentSensorData"
                        value={formData.recentSensorData}
                        onChange={handleChange}
                    />
                </div>
                <button type="button" onClick={handleSave}>
                    Save
                </button>
            </form>
        </div>
    );
};

export default AddFile;
